#include "table.h"

#include <vector>

int countSubsets(int M, int N, int K, std::vector<int> C, std::vector<int> D) {
  return 0;
}
