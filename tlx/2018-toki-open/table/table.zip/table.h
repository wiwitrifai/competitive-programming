#ifndef __TABLE_H__
#define __TABLE_H__

#include <vector>

int countSubsets(int M, int N, int K, std::vector<int> C, std::vector<int> D);

#endif
