#include "mining.h"

void findGold() {
  answer(1, 1);
}
