#ifndef __MINING_H__
#define __MINING_H__

bool isIntegerDistance(int A, int B);
void answer(int A, int B);
void findGold();

#endif
