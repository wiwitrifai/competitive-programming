#ifndef __TETRIS_H__
#define __TETRIS_H__

#include <string>
#include <vector>

std::vector<int> arrangeTetrominoes(int N, std::string S, int Q);

#endif
