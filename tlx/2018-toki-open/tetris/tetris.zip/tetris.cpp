#include "tetris.h"

#include <string>
#include <vector>

std::vector<int> arrangeTetrominoes(int N, std::string S, int Q) {
  std::vector<int> ans;
  return ans;
}
