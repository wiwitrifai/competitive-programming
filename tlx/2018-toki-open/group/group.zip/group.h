#ifndef __GROUP_H__
#define __GROUP_H__

#include <vector>

int getMinimumDelay(int N, std::vector<int> X, std::vector<int> Y);

#endif
