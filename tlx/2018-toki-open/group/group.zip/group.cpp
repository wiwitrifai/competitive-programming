#include "group.h"

#include <vector>

int getMinimumDelay(int N, std::vector<int> X, std::vector<int> Y) {
  return 0;
}
