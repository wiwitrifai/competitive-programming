#include "tour.h"

#include <string>
#include <vector>

int getShortestTour(int N, std::vector<std::string> S) {
  return 0;
}
