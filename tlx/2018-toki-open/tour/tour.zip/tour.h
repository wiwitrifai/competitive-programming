#ifndef __TILE_H__
#define __TILE_H__

#include <string>
#include <vector>

int getShortestTour(int N, std::vector<std::string> S);

#endif
